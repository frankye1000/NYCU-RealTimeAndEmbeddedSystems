#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

main()
{
	double a,b;

    clrscr();
	scanf("%lf",&a);
	a = a+2.0;
	b = a/2.0;
	printf("%lf",b);



}